Dynamic Java Instrumentation for Performance Journaling  (DJIPJL)
Copyright 2013 Siemens PLM Software.  All rights reserved.

***FOR SIEMENS PLM INTERNAL USE ONLY***

IMPORTANT: The installation and use of this software is restricted to the
employees of Siemens Product Lifecycle Management Software Inc. and/or its
subsidiaries (collectively, "Siemens PLM").

BY CONTINUING TO USE THIS PROGRAM, YOU ARE CERTIFYING THAT YOU ARE
AN EMPLOYEE OF SIEMENS PLM.

Siemens PLM Retains Ownership of Software.
    Siemens Product Lifecycle Management Software Inc. and/or its
subsidiaries (collectively, "Siemens PLM") owns certain rights in this
software program, and any associated media, printed materials, "online"
documentation and electronic documentation (the "Software").  THIS SOFTWARE
IS A PROPRIETARY PRODUCT OF SIEMENS PLM AND IS PROTECTED BY COPYRIGHT LAWS
AND OTHER INTELLECTUAL PROPERTY LAWS. TITLE TO THIS SOFTWARE, ANY COPY OF
THIS SOFTWARE, AND ANY INTELLECTUAL PROPERTY RIGHTS IN THE SOFTWARE SHALL AT
ALL TIMES REMAIN WITH SIEMENS PLM.  Except as set forth below, your rights are
defined by this License Agreement which you agree creates a legally binding
and valid contract. This Agreement shall terminate automatically if you fail
to comply with any of the terms described herein. All rights not specifically
granted in this License Agreement are reserved by Siemens PLM.

Restrictions.
    You may not reverse engineer, decompile, translate, disassemble, or
otherwise attempt to discover the source code or protocols of the Software as
it contains trade secrets of Siemens PLM. You may not otherwise modify, alter,
adapt, or merge the Software. You may not remove or obscure Siemens PLM
patent, trademark, or copyright notices.  You may not transfer, sell,
sublicense, lease, distribute, or rent this Software or the license granted
by this Agreement.

------------------------------------------------------------------------------


Dynamic Java Instrumentation for Performance Journaling (DJIPJL) enables the
generation of performance journal (PJL) files from nearly any Java
application.  It is built on the standard Java Virtual Machine Tools
Interface (JVM TI) and works using the same technology that a full Java
profiler application would use.  It is capable of generating much of the same
detail that a full Java profiling application would produce, however it does
not require a development environment as is generally required with most
profiling tools.  It is designed to be suitable for use in a testing or even
a production environment, producing PJL files with as little overhead as
possible which can then be post-processed and analyzed with the
JournalWorkbench tool.

When DJIPJL is enabled for a Java application a PJL file will be created when
the process starts and will track activity from that point in time until the
application process terminates.  The activity that is logged to the PJL file
is controlled by a properties file specified when DJIPJL is enabled.



DJIPJL XML FILTERS:

The properties file with the DJIPJL configuration must specify one or more
XML filter files.  These filters contain the exact specifications of what
will be instrumented and how it will be instrumented.  The format of these
filters is defined in the filter_schema.xsd file.  The schema contains
documentation for the elements and attributes of a filter.  It is strongly
suggested that an XML editor which can enforce the XML schema as well as
display the schema documentation annotations be used when editing DJIPJL
filter XML files.



INSTALLATION & CONFIGURATION:

There is no installation program, the files from the DJIPJL distribution kit
must only be extracted to a directory.  This directory will be referred to
as <DJIPJL_HOME>.

DJIPJL is enabled by specifying the -agentpath JVM argument and providing the
path to the appropriate DJIPJL shared library for the architecture being used.
A properties file with configuration options should also be specified.  The
format for the -agentpath argument is:

    -agentpath:<DJIPJL_HOME>\djipjl_<ARCHITECTURE>=<PROPERTIES_FILE>

Note: For Linux the <ARCHITECTURE> portion of the string must contain the
djipjl shared library file extension.

The properties file can be in the same directory as the DJIPJL shared
library file, in which case only the filename should be specified.  If the
properties file is in another directory the full path name must also be
specified here.  An attempt to open a file named djipjl.properties will be
made if a properties file is not specified.

The properties file contains basic configuration parameters such as the
output directory and one or more XML filters that specify how the application
is to be instrumented.


Configurations for the Teamcenter Rich Client are included:

1) Replace <DJIPJL_HOME> with your local directory and append the -agentpath
   string to the end of your Teamcenter.ini file.

   For 32-bit RAC on Windows:
       -agentpath:<DJIPJL_HOME>\djipjl_win32=rac.properties

   For 64-bit RAC on Windows:
       -agentpath:<DJIPJL_HOME>\djipjl_win64=rac.properties

   For 64-bit RAC on Linux:
       -agentpath:<DJIPJL_HOME>/djipjl_lnx64.so=rac.properties


2) Edit the rac.properties file and change the outputDirectory property to a
   valid directory.



TROUBLESHOOTING:

- If the application fails to start double check that the -agentpath option
specified for the JVM does not contain any typos in the specification of the
directory path to the djipjl shared library file.

- If no output is produced in the PJL file check the djipjl*.log file in
the output directory.  If the log file does not exist verify that the
properties file has logging enabled and that the outputDirectory is correct.

- Look for any djipjl_err_*.log files that might have been created in the
applications current working directory, or the system TEMP directory.

